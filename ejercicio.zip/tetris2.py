import numpy as np


def solution(figure,field):

    figure=np.array(figure)
    field = np.array(field)

    for columna in range(0,len(field[0])-2): #len(field[0])-2 :   2

        for fila in range(0,len(field)-2): # len(field)-2:   3

            sub_field = field[fila:(3+fila),columna:(columna+3)]
            c= figure + sub_field


            if(2 in c and fila>0):

                if(verificarLinea(resultante)):
                    return columna

                if(verificarLinea(resultante)==False and columna == (len(field[0]) - 3)):
                    return -1

                break

            if (2 in c and columna == (len(field[0]) - 3)):
                return -1

            if(2 in c and fila==0):
                break

            else:
                vacio = np.empty((3, 0), int)
                if (columna> 0 ):
                    vacio = np.append(vacio, np.array(field[fila:(3+fila),0:columna]), axis=1)
                    resultante= np.append(vacio, np.array(c), axis=1)
                    resultante = np.append(resultante, np.array(field[fila:3 + fila, columna + 3:len(field[0])]), axis=1)
                else:
                    resultante = np.append(c, np.array(field[fila:3+fila,columna+3:len(field[0])]), axis=1)

            if(fila == len(field)-3):
                if (verificarLinea(resultante)):
                    return columna



def verificarLinea(resultante):

    for i in range(0, 3):
        if (np.all(resultante[i] == 1)):
            return True
    return False



figure = [[1, 1, 1],
           [1,0,0],
           [1,0,0]]

field = [[0, 0, 0,0,0,0],
         [0, 0, 0,0,0,0],
         [0, 0, 0,1,1,1],
         [0, 1, 1,1,1,1],
         [1, 1, 0,1,1,1]
         ]
'''
field = [[0, 0, 0],
         [0, 0, 0],
         [0, 0, 0],
         [1, 0, 0],
         [1, 1, 0]
         ]
'''

print("la solución es:",solution(figure,field))